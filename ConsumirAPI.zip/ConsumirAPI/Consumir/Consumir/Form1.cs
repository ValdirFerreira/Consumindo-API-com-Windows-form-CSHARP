﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Consumir
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNome.Text))
                MessageBox.Show("Informe o Nome");
            else
            {
                Cadastrar(txtNome.Text);
            }
        }

        public void Cadastrar(string valor)
        {
            Random Codigo = new Random();

            Usuario User = new Usuario { Id = Codigo.Next(9999), Nome = valor };
            string Json = JsonConvert.SerializeObject(User);

            var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://localhost/Rede.MI.Api/Comprovante/EnviarComprovante");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                try
                {
                    streamWriter.Write(Json);
                    streamWriter.Flush();
                    streamWriter.Close();
                    var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        var result = streamReader.ReadToEnd();
                        MessageBox.Show(result.ToString());
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("A Conexão foi perdida");
                }
            }
        }

    }
}